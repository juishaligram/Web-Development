const facebook = {
    clientID: '340100819812558',
    clientSecret: '534199fb0a8251d6de3c0bd16bdb7914',
    callbackURL: 'https://localhost:8000/auth/facebook/callback',
    profileFields: ['id', 'name', 'displayName', 'picture', 'email'],
  };

  module.exports=facebook;