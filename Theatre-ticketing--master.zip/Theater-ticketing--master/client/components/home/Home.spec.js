import expect from 'expect'

describe('empty', ()=>{
    it('should work',()=>{
        expect(true).toEqual(true);
    })
})